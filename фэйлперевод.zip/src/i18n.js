import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import i18nextHttpBackend from "i18next-http-backend"; // <-- НОВЫЙ ИМПОРТ

i18n
  .use(i18nextHttpBackend) // <-- ПОДКЛЮЧАЕМ БЭКЕНД-АДАПТЕР
  .use(initReactI18next)
  .init({
    // УДАЛЯЕМ БЛОК `resources`, ТЕПЕРЬ ОН НЕ НУЖЕН
    lng: "ru",
    fallbackLng: "ru",
    
    // --- НОВЫЕ НАСТРОЙКИ ---
    // Указываем, где искать файлы с переводами
    backend: {
      loadPath: '/locales/{{lng}}/translation.json',
    },
    // --- КОНЕЦ НОВЫХ НАСТРОЕК ---

    interpolation: {
      escapeValue: false 
    }
  });

  export default i18n;