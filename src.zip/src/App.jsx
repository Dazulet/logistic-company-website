import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import { ThemeProvider } from './Context/ThemeContext'
import Navbar from './components/Navbar'
import HeroSection from './components/section/HeroSection'
import SkillsSection from './components/section/SkillsSection'
import AboutSection from './components/section/AboutSection'
import ContactSection from "./components/section/ContactSection";

const App = () => {

  return (
    <ThemeProvider>
      <div className="pb-[100vh] ">
        <Navbar />
        <HeroSection/>
        <SkillsSection/>
        <AboutSection/>
        <ContactSection/>
      </div>
    </ThemeProvider>
  )
}

export default App
