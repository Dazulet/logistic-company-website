// App.jsx
import { ThemeProvider } from './Context/ThemeContext'
import Navbar from './components/Navbar'
import HeroSection from './components/section/HeroSection'
import ServicesSection from './components/section/ServicesSection'
import AboutCompanySection from './components/section/AboutCompanySection'
import CasesSection from './components/section/CasesSection'; // 1. Импортируем новый компонент
import ContactUsSection from "./components/section/ContactUsSection";


const App = () => {

  return (
    <ThemeProvider>
      {/* Убрал pb-[100vh] для более естественного скролла */}
      <div> 
        <Navbar />
        <HeroSection/>
        <ServicesSection/>
        <AboutCompanySection/>
        <CasesSection /> {/* 2. Добавляем компонент сюда */}
        <ContactUsSection/>
      </div>
    </ThemeProvider>
  )
}

export default App